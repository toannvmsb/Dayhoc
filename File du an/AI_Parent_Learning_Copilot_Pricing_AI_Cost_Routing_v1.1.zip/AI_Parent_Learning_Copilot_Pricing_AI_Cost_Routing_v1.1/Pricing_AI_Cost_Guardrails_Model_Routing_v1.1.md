# AI Parent Learning Copilot
# Pricing + AI Cost Guardrails + Model Routing — v1.1

**Status:** Architecture/financial specification for Claude update  
**Supersedes:** v1.0  
**Core change:** `AI_GENERATION_FIRST`

---

## 1. Locked product correction

The product does **not** use a prebuilt Verified Question Bank as the normal source of student exercises.

The default loop is:

`Curriculum Clock → Learning Context Resolver → Child Learning Twin + Gap + Parent Goal → Next Best Learning Action → ExerciseGenerationSpec → AI Generator → Validation → Child Attempt → Evidence → Twin Update → repeat`

A Golden/Reference Problem Library may exist only for:
- grounding;
- examples of problem families;
- generator evaluation;
- validation;
- golden testing.

It must not become the primary delivery mechanism for ordinary personalized practice.

---

## 2. Curriculum Clock

The application must function even when neither parent nor teacher updates the current lesson.

`CurriculumClockService(child, date)` estimates the current curriculum position from:
- selected curriculum/textbook;
- academic year;
- school start date;
- school week;
- semester boundaries;
- known holidays/breaks;
- expected pacing.

Output must include:
- `expected_context`;
- `source=CURRICULUM_TIMELINE`;
- `confidence=ESTIMATED`;
- `as_of_date`.

The estimated context is a baseline, not verified truth.

### Learning Context Resolver

Resolve context using evidence priority, recency, consistency and confidence.

Conceptual order:

`Teacher/Parent confirmed context + observed schoolwork/test/notebook evidence > estimated curriculum timeline`

Do not blindly overwrite a recent verified context with a calendar estimate.

Store both:
- expected curriculum context;
- resolved actual learning context;
- source;
- confidence;
- last_verified_at;
- pace_delta.

Repeated observed evidence may update the estimated class pace.

---

## 3. Personalized exercise generation

Current lesson alone never determines exercise difficulty.

The deterministic education layer must combine:
- resolved learning context;
- relevant skill/prerequisite graph;
- Child Learning Twin;
- confirmed/hypothesized gaps;
- readiness;
- Actual Learning Frontier;
- thinking profile;
- parent goal;
- available learning time.

It produces `ExerciseGenerationSpec`.

The LLM creates content **inside the spec**. It does not decide the curriculum or invent skill IDs.

### Required ExerciseGenerationSpec shape

```yaml
child_context:
  school_grade: 7
learning_context:
  curriculum: KET_NOI_TRI_THUC
  current_lesson_id: ...
  source: PARENT_UPDATE | TEACHER_UPDATE | SCHOOLWORK_EVIDENCE | CURRICULUM_TIMELINE
  confidence: VERIFIED | STRONG | SUPPORTING | ESTIMATED
target:
  skill_ids: [...]
  problem_types: [...]
child_state:
  mastery: ...
  prerequisite_gaps: [...]
  thinking_profile: ...
  actual_learning_frontier: ...
parent_goal:
  type: SCHOOL_MASTERY | ADVANCED | HSG | EXAM
generation_plan:
  total_questions: 10
  distribution:
    prerequisite_repair: 2
    current_skill: 3
    variation: 2
    advanced: 2
    thinking_challenge: 1
  K_range: {min: K2, max: K4}
  T_range: {min: T2, max: T5}
constraints:
  no_unlearned_required_knowledge: true
  allow_above_grade_reasoning: true
  require_unique_variants: true
```

---

## 4. Batch generation economics

Daily worksheet mode should normally use **one generation call for a batch**, not one call per question.

Preferred:

`1 ExerciseGenerationSpec → 1 AI generation → N questions + answers + solutions + metadata → validation`

Interactive Adaptive Mode is different: after new evidence (wrong answer, hint dependency, fast success, etc.), the system may generate the **Next Best Question**.

Therefore track separately:
- `WORKSHEET_BATCH_GENERATION`;
- `NEXT_BEST_QUESTION`;
- `VISION_EXTRACTION`;
- `ERROR_DIAGNOSIS`;
- `PARENT_COPILOT`;
- `TEACH_ME`;
- `WEEKLY_SUMMARY`;
- `EXAM_REVISION`;
- `ADVANCED_VERIFICATION`.

---

## 5. Commercial pricing

Keep current proposed pricing:

| Plan | Price/month | AI target | Operational ceiling | Absolute AI boundary before modeled margin <50% |
|---|---:|---:|---:|---:|
| FREE | 0 | 2K | 3K | acquisition budget |
| BASIC | 169K | 8K | 10K | 12.25K |
| PLUS ⭐ | 229K | 15K | 22K | 27.25K |
| PRO | 329K | 28K | 40K | 52.25K |

Financial assumptions:
- Store/payment reserve: 15% revenue.
- Tax reserve: 10% revenue.
- Server/data allocation: 10K paid user/month.
- HR + marketing allocation: 20K paid user/month.
- Required modeled margin floor: 50%.

For paid plans:

`Modeled Profit = Price × 75% − 30K − AI COGS`

Therefore:

`Maximum AI COGS at 50% modeled margin = Price × 25% − 30K`

Operational ceilings intentionally remain below the mathematical boundary.

### Modeled margin at operational ceiling

- BASIC: ~51.3%
- PLUS: ~52.3%
- PRO: ~54.0%

These are contribution-style planning margins, **not final accounting profit**. Pilot economics must later incorporate real CAC, fixed payroll, refunds, support, store mix, tax structure and Free subsidy.

---

## 6. Plan behavior

### FREE
Goal: real product value, not a fake trial.

Target:
- limited AI-generated personalized practice (planning assumption ~10 days/month);
- ~2 scan pages/month;
- basic context/twin/gap;
- a small number of AI magic moments.

When Free reaches budget pressure, prefer cached/reusable personalized outputs and deterministic transformations. Do not fake a fresh AI diagnosis.

### BASIC — 169K
AI-generated Daily Practice can be a normal daily feature.
Mainly Luna.
Basic Gap/Twin/revision and limited scans.
AI target 8K; operational ceiling 10K.

### PLUS — 229K
Primary recommended plan.
Daily AI practice + adaptive Next Best Question where useful.
Full Twin/Gap, Parent Copilot, Teach Me, Thinking Challenge, Exam Intelligence, limited cross-grade.
AI target 15K; operational ceiling 22K.

### PRO — 329K
Advanced/HSG/Olympiad/cross-grade/deeper adaptive learning.
Higher legitimate advanced-model use.
AI target 28K; operational ceiling 40K.

**Plan tier must never itself select the expensive model.**
Educational need + confidence + difficulty selects the model.

---

## 7. Model routing

### Default production
`GPT-5.6 Luna`

Use for the majority of:
- Vision/extraction;
- content classification;
- skill/problem-type candidate mapping;
- standard exercise generation;
- worksheet batch generation;
- basic error diagnosis;
- parent summaries;
- Teach Me;
- Daily Plan explanation;
- standard Next Best Question.

### Advanced candidate
Do **not** lock provider yet.

Benchmark:
- GPT-5.6 Terra;
- Claude Sonnet.

Candidate triggers:
- K4/K5;
- T4/T5;
- HSG/Olympiad;
- difficult proof;
- nonlinear algebra;
- complex root-gap diagnosis;
- Luna verifier failure;
- confidence below routing threshold.

Select the cheapest advanced pipeline that passes quality gates for the relevant workload.

### Quality evaluation
`GPT-5.6 Sol`

Primarily offline:
- Golden QA;
- generator audit;
- difficult benchmark adjudication;
- regression evaluation.

Do not use Sol as routine production.

### OCR
Luna image input is the baseline.
A separate OCR provider remains an adapter/fallback until the real-image benchmark demonstrates material quality/cost benefit.

---

## 8. Validation boundary

AI may propose:
- transcription;
- content blocks;
- candidate skill mappings;
- generated questions;
- solutions;
- explanations;
- error hypotheses.

Deterministic systems own:
- production skill IDs;
- prerequisite DAG;
- permissions;
- gap lifecycle;
- readiness rules;
- planner constraints;
- cost guardrails;
- schema enforcement.

Generated exercises must be validated before delivery.

High-risk/advanced items may require an AI verifier in addition to deterministic checks.

---

## 9. Cost optimization ladder

Optimize in this order:

1. Send only relevant curriculum/skill/prerequisite/Twin context.
2. Cache stable system rules and schemas.
3. Batch-generate worksheets.
4. Use deterministic validation first.
5. Call AI verifier selectively.
6. Luna-first.
7. OCR fallback only where measured useful.
8. Advanced escalation only where educationally required.

Do **not** solve cost problems by reverting the product to a generic static question bank.

---

## 10. Cost telemetry

Every AI/OCR call must record at least:

```yaml
provider:
model:
model_version:
price_config_effective_date:
operation_type:
user_id:
child_id_pseudonymous:
plan:
input_tokens:
cached_input_tokens:
output_tokens:
image_count:
ocr_pages:
estimated_cost_usd:
estimated_cost_vnd:
latency_ms:
confidence:
retry_count:
escalated_from:
escalation_reason:
generation_spec_id:
learning_context_source:
K_target:
T_target:
```

No child name or unnecessary PII should be required in cost telemetry.

---

## 11. Budget Guardrail states

### GREEN
Projected monthly AI COGS ≤ target.

### YELLOW
Target < projected COGS ≤ operational ceiling.

Actions:
- inspect usage;
- improve caching/batching;
- reduce unnecessary verifier calls;
- improve routing;
- detect retries/bugs.

Do not degrade core educational quality.

### RED
Projected COGS > operational ceiling.

Actions:
- identify abuse/anomaly;
- block pathological retry loops;
- restrict non-essential expensive operations;
- force standard tasks to default route;
- preserve educationally necessary advanced escalation.

### BLOCKER
Projected paid-plan economics exceeds the absolute 50% modeled-margin boundary.

Requires product/finance approval before rollout.

---

## 12. Cost forecasting

Do not forecast only by `tokens/user`.

Forecast by operation:

`Monthly AI COGS = Σ(operation volume × measured unit cost × retry/escalation factor)`

Required dimensions:
- plan;
- grade;
- K/T;
- standard vs advanced;
- scan type;
- active days;
- worksheet batches;
- Next Best Questions;
- Parent Copilot sessions;
- exam periods;
- advanced escalation rate.

Recalculate after the AI/OCR benchmark and again during pilot.

---

## 13. Benchmark integration

Use the existing AI/OCR Benchmark Kit.

Benchmark must decide:
1. Is Luna sufficient for default Vision?
2. Does separate OCR materially improve Vietnamese handwriting/math?
3. Terra vs Sonnet for advanced/HSG.
4. Confidence thresholds for escalation.
5. Real VND/page and VND/operation.
6. Projected AI COGS by plan under AI-generation-first usage.

No production advanced provider should be locked before results.

---

## 14. Claude implementation instructions

Before coding provider-specific production behavior, update:
- `CLAUDE.md`;
- Technical Architecture;
- AI Orchestration Plan;
- Math Engine Plan;
- database/cost telemetry model;
- Provider Adapter;
- Planner contracts.

Add:
- `CurriculumClockService`;
- `LearningContextResolver`;
- `ExerciseGenerationSpec`;
- `ExerciseGenerator`;
- `GeneratedExerciseValidator`;
- `AIModelRouter`;
- `AIBudgetGuardrail`;
- `AICostLedger`.

### Acceptance tests

At minimum:

1. New child + no teacher/parent update → estimated SGK context is returned with `ESTIMATED` confidence.
2. Parent/teacher verified context can override timeline estimate.
3. Repeated schoolwork evidence can change pace estimate without destroying verified history.
4. Two children at same lesson but different Twin/goal receive different GenerationSpecs.
5. AI cannot create a new production skill ID.
6. Standard 10-question worksheet is batch-generated.
7. T4/T5/HSG may escalate; plan tier alone cannot.
8. Low-confidence Vision cannot silently update Twin.
9. Cost is logged for every AI/OCR call.
10. Paid-plan forecast crossing operational ceiling raises RED.
11. Crossing 50% absolute economics boundary raises BLOCKER.
12. No fallback to static question-bank-first architecture.

---

## 15. Decision still intentionally open

Do not prematurely lock:
- Terra vs Claude Sonnet as advanced provider;
- separate OCR as default/fallback;
- exact confidence thresholds;
- exact real-world monthly AI COGS.

Those are outputs of benchmark + pilot telemetry.

**Pricing remains 169K / 229K / 329K unless measured economics show the modeled margin floor cannot be maintained.**
