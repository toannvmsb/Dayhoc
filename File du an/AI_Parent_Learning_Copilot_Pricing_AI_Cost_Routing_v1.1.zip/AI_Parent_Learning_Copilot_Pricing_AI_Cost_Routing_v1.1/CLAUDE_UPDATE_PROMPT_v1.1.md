# Claude Update Prompt — Pricing/AI Cost/Model Routing v1.1

Read `Pricing_AI_Cost_Guardrails_Model_Routing_v1.1.md` as the replacement for v1.0.

Important correction:
- Product is AI-generation-first.
- Do not use Verified Question Bank as normal exercise delivery.
- Add CurriculumClockService, LearningContextResolver and ExerciseGenerationSpec.
- Daily worksheet generation should be batched.
- Adaptive Next Best Question is event-driven after new learning evidence.
- Luna is default.
- Terra vs Claude Sonnet advanced route remains benchmark-dependent.
- Sol is offline quality/golden evaluation.
- Separate OCR is benchmark-dependent.
- Keep plan pricing and AI guardrails from v1.1.
- Update cost telemetry and forecast by operation, not only tokens/user.

Update CLAUDE.md, architecture and implementation docs first.
Produce a change report showing every place where v1.0/question-bank-first assumptions were removed or superseded.
Do not start provider-specific production implementation until the architecture update is reviewed.
