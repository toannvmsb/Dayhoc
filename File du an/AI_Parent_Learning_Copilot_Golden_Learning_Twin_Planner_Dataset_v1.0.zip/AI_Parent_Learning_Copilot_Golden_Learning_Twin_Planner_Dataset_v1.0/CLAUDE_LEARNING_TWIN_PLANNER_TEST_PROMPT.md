# CLAUDE CODE PROMPT — GOLDEN LEARNING TWIN & PLANNER TEST HARNESS

Đọc Math Dev Core v1.0 → Golden Test Dataset v1.0 → Golden Error Dataset v1.0 → dataset này.

Xây baseline test harness cho Evidence → Twin → Gap → Readiness → Planner.

Bắt buộc test: append-only evidence, confidence hierarchy, skill-specific mastery/frontier, gap hypothesis vs confirmed gap, careless/hint/retention/thinking behaviors, readiness, Learning Mix, Next Best Learning Action, Daily Plan time budget, exam mode, cross-grade invariants và toàn bộ curated scenarios.

Không hard-code profile_id/case_id; không tự sửa expected; không tạo production Skill ID mới; không collapse trẻ thành global grade level.

Mismatch report: profile_id | layer | expected | actual | invariant_violated | likely_cause | suggested_fix

Nếu nghi golden expected sai: CONTENT_REVIEW_REQUIRED. Dừng sau baseline report.
