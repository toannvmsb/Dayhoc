# CLAUDE CODE PROMPT — GOLDEN END-TO-END FAMILY JOURNEY

Đọc theo thứ tự:
1. Product Blueprint + Technical Spec + UI/UX Spec
2. Math Core Grade 4/7
3. Golden Test Dataset
4. Golden Error Dataset
5. Golden Learning Twin & Planner Dataset
6. Golden End-to-End Family Journey Dataset này

Xây E2E test harness nhưng KHÔNG hard-code journey_id để pass.

Với từng journey:
- seed family/child;
- chạy onboarding;
- ingest/upload simulated schoolwork;
- test AI contracts bằng fixture/mocked provider khi cần;
- append evidence;
- rebuild Twin;
- run Gap/Readiness/Planner;
- test Parent Copilot response contract;
- test ChildTaskViewModel projection;
- run retest/retention;
- nếu có exam, chạy exam flow;
- compare expected checkpoints.

Bắt buộc chạy toàn bộ E2E_INVARIANTS và failure_recovery_scenarios.

Mismatch:
journey_id | step_id | layer | expected | actual | invariant_violated | likely_cause | suggested_fix

Không sửa golden expected để pass.
Nghi dữ liệu golden sai → CONTENT_REVIEW_REQUIRED.
Invariant fail → BLOCKER.
Dừng sau baseline report, chờ phê duyệt.
