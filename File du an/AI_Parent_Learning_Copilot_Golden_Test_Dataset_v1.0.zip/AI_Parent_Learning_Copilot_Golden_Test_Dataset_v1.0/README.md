# AI Parent Learning Copilot — Golden Test Dataset v1.0

## Nội dung
- 120 golden question cases: 60 Grade 4 + 60 Grade 7
- 12 golden student profiles
- JSONL cho automated tests
- YAML cho content review
- JSON Schema cho contract validation

## Mỗi case kiểm thử
`skill_id + problem_type + Knowledge Level + Thinking Level + expected_answer + root-gap expectation`.

## Provenance
Exact question text trong dataset chủ yếu là **synthetic test fixture**, được tạo để kiểm thử engine; không phải bản sao SGK.
Taxonomy, curriculum family, problem family và cross-grade rules được ground vào Math Core đã khóa.
Các case bám cấu trúc bộ 13/8, 15/8 và Biến đổi đồng nhất được đánh dấu bằng `golden_source_pattern` hoặc mô tả ở `source_basis`.

## Cách dùng
1. Mapping test: prompt → Skill / Problem Type / K / T.
2. Answer verifier: output phải tương thích expected answer.
3. Gap test: mô phỏng câu trả lời sai và kiểm root-gap classification.
4. Cross-grade test: Grade 7 + G8/G9/HSG exposure không được tạo global Grade 9 mastery.
5. Profile test: chạy 12 profile qua Twin → Gap → Readiness → Planner.

## Gate khuyến nghị
- Schema: 100%
- Skill/problem mapping: ≥95% ở curated standard cases
- Math answer verifier: ≥99%
- Root-gap classification: ≥90% ở curated diagnosis cases
- Cross-grade invariants: 100%
- Không có production Skill ID do LLM tự tạo

## Lưu ý production
Grade 7 item-level `M7.*` đang là provisional normalization trong Math Dev Core v1.0; cần content review trước khi freeze production.
