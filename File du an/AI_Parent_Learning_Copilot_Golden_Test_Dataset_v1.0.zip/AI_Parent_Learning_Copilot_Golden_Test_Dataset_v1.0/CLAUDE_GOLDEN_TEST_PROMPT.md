# CLAUDE CODE PROMPT — GOLDEN TEST HARNESS

Đọc toàn bộ thư mục Golden Test Dataset v1.0.

Yêu cầu:
1. Parse JSONL và validate JSON Schema.
2. Viết test harness cho skill mapping, problem-type mapping, K/T classification, answer verification và root-gap diagnosis.
3. Nạp 12 student profile để test Twin/Gap/Readiness/Planner.
4. Mismatch phải xuất `case_id`, expected, actual, delta, likely_cause.
5. Không tự sửa expected result để test pass.
6. Nếu nghi expected answer sai: đánh dấu `CONTENT_REVIEW_REQUIRED`.
7. Không tạo production Skill ID mới.
8. Grade 7 M7 IDs vẫn provisional.
9. Dừng sau baseline report; chờ phê duyệt trước khi tune engine/prompt.
