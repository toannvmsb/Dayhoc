# CLAUDE CODE PROMPT — GOLDEN ERROR / GAP ENGINE TESTS

Đọc Golden Test Dataset v1.0 trước, sau đó đọc toàn bộ Golden Error Dataset v1.0.

Mục tiêu: xây test harness cho Error Diagnosis + Knowledge Gap Engine. KHÔNG tune prompt/engine để làm test pass bằng cách hard-code case_id.

Yêu cầu:
1. Validate `golden_errors.jsonl` theo schema.
2. Với mỗi error case, test:
   - error_signature
   - expected_gap_type
   - root_cause_class
   - prerequisite trace
   - mastery update behavior
   - diagnostic follow-up
3. Chạy toàn bộ curated scenarios.
4. Invariant bắt buộc:
   - careless_error → minimal knowledge penalty
   - single observation → không high-confidence confirmed gap
   - parent-only feedback → hypothesis, không confirmed gap
   - T4/T5 failure → ưu tiên thinking/recognition diagnosis nếu K2/K3 evidence mạnh
   - above-grade failure → không downgrade grade-level mastery tự động
   - frontier lưu theo skill/domain, không global grade
5. Mismatch report:
   `error_case_id | expected | actual | violated_invariant | likely_cause | suggested_fix`
6. Không tự sửa golden expected.
7. Nếu golden data nghi sai → `CONTENT_REVIEW_REQUIRED`.
8. Dừng sau baseline report và chờ phê duyệt.
