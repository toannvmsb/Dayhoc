# AI Parent Learning Copilot — Golden Error Dataset v1.0

## Mục tiêu
Kiểm thử phần khó nhất của sản phẩm: **không chỉ biết con sai, mà hiểu con sai vì đâu và engine nên phản ứng thế nào**.

## Quy mô
- 120 source golden questions
- 360 synthetic error cases (3 lỗi điển hình / question)
- 15 curated high-value diagnosis scenarios
- Bao phủ 11 gap types

## Error taxonomy
`concept_gap`, `prerequisite_gap`, `method_gap`, `recognition_gap`, `application_gap`,
`reasoning_gap`, `procedural_gap`, `retention_gap`, `careless_error`, `reading_error`, `presentation_error`.

## Golden diagnosis pipeline
Observed Error → Error Signature → Skill/Problem Type → Prerequisite Trace → Root Gap Hypothesis
→ Diagnostic Follow-up → Confirm/Reject → Prescription → Re-test → Retention Check.

## Non-negotiable rules
1. Một lỗi đơn lẻ không đủ để tạo high-confidence gap.
2. Careless error không được kéo mạnh Knowledge Mastery.
3. T4/T5 fail có thể là Thinking/Recognition Gap dù knowledge vẫn mạnh.
4. Fail bài G8/G9/HSG không đồng nghĩa yếu Toán 7.
5. Parent feedback tạo Gap Hypothesis; cần diagnostic để xác nhận.
6. Evidence verified phải có trọng số cao hơn observation ước lượng.
7. LLM đề xuất diagnosis; deterministic engine quyết định lifecycle/threshold/mastery update.

## Test harness
Chạy theo 6 lớp:
- schema validation
- error-signature classification
- root-gap classification
- prerequisite trace
- mastery-update invariant
- prescription/retest invariant

## Lưu ý provenance
Các wrong-response pattern là synthetic fixtures để kiểm thử diagnosis. Không nên coi chúng là dữ liệu thống kê thực tế về lỗi học sinh cho đến khi có pilot data.
